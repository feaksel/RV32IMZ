# CSR and Trap Handling Architecture Overview

**Visual Guide to CSR, Exceptions, and Interrupts**

---

## Complete System Architecture

```
┌────────────────────────────────────────────────────────────────────────┐
│                       RISC-V Core (RV32IM)                              │
│                                                                         │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │                    Pipeline Control                               │  │
│  │  ┌─────────┐   ┌─────────┐   ┌─────────┐   ┌─────────┐         │  │
│  │  │  FETCH  │──▶│ DECODE  │──▶│ EXECUTE │──▶│   WB    │         │  │
│  │  └────┬────┘   └────┬────┘   └────┬────┘   └─────────┘         │  │
│  │       │             │             │                              │  │
│  │       │             │             │                              │  │
│  └───────┼─────────────┼─────────────┼──────────────────────────────┘  │
│          │             │             │                                 │
│          │             │             │                                 │
│   ┌──────▼─────────────▼─────────────▼──────────┐                     │
│   │          Exception Detection                 │                     │
│   │                                               │                     │
│   │  • Illegal instruction                       │                     │
│   │  • Address misaligned                        │                     │
│   │  • Access fault                              │                     │
│   │  • ECALL / EBREAK                            │                     │
│   └──────────────────┬───────────────────────────┘                     │
│                      │ exception_taken                                 │
│                      │ exception_cause                                 │
│                      │                                                 │
│   ┌──────────────────▼───────────────────────────┐                     │
│   │       Trap Control State Machine             │                     │
│   │                                               │                     │
│   │  Normal → Exception → TRAP → Handler         │                     │
│   │             │                                 │                     │
│   │         Interrupt ────┘                      │                     │
│   │                                               │                     │
│   └──────────────────┬───────────────────────────┘                     │
│                      │ trap_entry / trap_return                        │
│                      │                                                 │
│   ┌──────────────────▼───────────────────────────┐                     │
│   │            CSR Unit                           │                     │
│   │                                               │                     │
│   │  • Save PC → mepc                            │                     │
│   │  • Save cause → mcause                       │                     │
│   │  • Disable interrupts (MIE ← 0)              │                     │
│   │  • Provide trap_vector                       │                     │
│   │  • Performance counters                      │                     │
│   │                                               │                     │
│   └───────────────────────────────────────────────┘                     │
│                                                                         │
│   ┌───────────────────────────────────────────────┐                     │
│   │      Interrupt Controller                     │                     │
│   │                                               │                     │
│   │  Priority: External > Software > Timer       │                     │
│   │                                               │                     │
│   │  Inputs: timer_int, external_int, etc.      │                     │
│   │  Output: interrupt_req, interrupt_cause      │                     │
│   │                                               │                     │
│   └───────────────────────────────────────────────┘                     │
│                                                                         │
└────────────────────────────────────────────────────────────────────────┘
           │                                               │
           │ External Interrupts                          │
           │                                               │
    ┌──────▼──────┐  ┌──────────┐  ┌──────────┐  ┌──────▼──────┐
    │    Timer    │  │   ADC    │  │   PWM    │  │   Memory    │
    │  Peripheral │  │Interface │  │Accelerator│  │  (Wishbone) │
    └─────────────┘  └──────────┘  └──────────┘  └─────────────┘
```

---

## Trap Flow Diagram

### Exception Flow (Synchronous)

```
┌─────────────────────────────────────────────────────────────────┐
│                    Normal Execution                              │
│                                                                  │
│  PC = 0x1000  →  Fetch instruction  →  Decode  →  Execute      │
│                                                        │         │
│                                                        │         │
│                                              ┌─────────▼─────┐   │
│                                              │  Illegal Inst  │   │
│                                              │   Detected!    │   │
│                                              └────────┬───────┘   │
└──────────────────────────────────────────────────────┼───────────┘
                                                       │
                                                       │ exception_taken = 1
                                                       │ exception_cause = 2
                                                       │
                                              ┌────────▼───────┐
                                              │  CSR Unit      │
                                              │  Trap Entry    │
                                              │                │
                                              │  mepc ← PC     │
                                              │  mcause ← 2    │
                                              │  MIE ← 0       │
                                              │  MPIE ← old MIE│
                                              └────────┬───────┘
                                                       │ trap_vector
                                                       │
┌──────────────────────────────────────────────────────┼───────────┐
│                  Exception Handler                   │           │
│                                                      │           │
│  PC = trap_vector  →  Save registers (if needed)    │           │
│                    →  Handle exception               │           │
│                    →  Restore registers              │           │
│                    →  Execute MRET                   │           │
│                                        │             │           │
│                              ┌─────────▼─────┐       │           │
│                              │  CSR Unit      │       │           │
│                              │  Trap Return   │       │           │
│                              │                │       │           │
│                              │  PC ← mepc     │       │           │
│                              │  MIE ← MPIE    │       │           │
│                              │  MPIE ← 1      │       │           │
│                              └────────┬───────┘       │           │
│                                       │               │           │
└───────────────────────────────────────┼───────────────┘           │
                                        │                           │
┌───────────────────────────────────────▼───────────────────────────┐
│                    Resume Execution                               │
│                                                                   │
│  PC = 0x1000 (or wherever we want to go)                         │
│           →  Continue normal execution                            │
│                                                                   │
└───────────────────────────────────────────────────────────────────┘
```

### Interrupt Flow (Asynchronous)

```
┌─────────────────────────────────────────────────────────────────┐
│                    Normal Execution                              │
│                                                                  │
│  PC = 0x1000  →  Fetch  →  Decode  →  Execute  →  ...          │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘

    ┌───────────────────────────────┐
    │  Timer Peripheral              │
    │                                │      10 kHz interrupt
    │  Counter reaches threshold ────┼────────────┐
    └────────────────────────────────┘            │
                                                  │
                                                  │ timer_int = 1
                                                  │
                                         ┌────────▼──────────┐
                                         │ Interrupt         │
                                         │ Controller        │
                                         │                   │
                                         │ Check:            │
                                         │ - mie[7] = 1?     │
                                         │ - mstatus.MIE = 1?│
                                         └────────┬──────────┘
                                                  │
                                                  │ interrupt_req = 1
                                                  │ interrupt_cause = 0x80000007
                                                  │
┌─────────────────────────────────────────────────┼───────────────┐
│                Core State Machine               │               │
│                                                 │               │
│  Check before next FETCH:                      │               │
│    if (interrupt_req && !stall)                │               │
│      → Trap to interrupt handler               │               │
│                                        ┌────────▼───────┐       │
│                                        │  CSR Unit      │       │
│                                        │  Trap Entry    │       │
│                                        │                │       │
│                                        │  mepc ← PC     │       │
│                                        │  mcause ← 0x87 │       │
│                                        │  MIE ← 0       │       │
│                                        │  MPIE ← 1      │       │
│                                        └────────┬───────┘       │
│                                                 │ trap_vector   │
└─────────────────────────────────────────────────┼───────────────┘
                                                  │
┌─────────────────────────────────────────────────▼───────────────┐
│                  Interrupt Handler                               │
│                                                                  │
│  PC = trap_vector  →  Save context                              │
│                    →  Read ADC values                            │
│                    →  Execute control algorithm                  │
│                    →  Update PWM duty cycles                     │
│                    →  Clear interrupt flag                       │
│                    →  Restore context                            │
│                    →  Execute MRET                               │
│                                        │                         │
│                              ┌─────────▼─────┐                   │
│                              │  CSR Unit      │                   │
│                              │  Trap Return   │                   │
│                              │                │                   │
│                              │  PC ← mepc     │                   │
│                              │  MIE ← 1       │                   │
│                              └────────┬───────┘                   │
│                                       │                           │
└───────────────────────────────────────┼───────────────────────────┘
                                        │
┌───────────────────────────────────────▼───────────────────────────┐
│                    Resume Execution                               │
│                                                                   │
│  PC = (whatever it was before interrupt)                         │
│           →  Continue where we left off                           │
│                                                                   │
└───────────────────────────────────────────────────────────────────┘
```

---

## CSR Register Organization

### Machine-Mode CSRs

```
┌─────────────────────────────────────────────────────────────────┐
│                     Machine Information                          │
├─────────────┬───────────────┬───────────────────────────────────┤
│ 0xF11       │ mvendorid     │ Vendor ID (read-only)             │
│ 0xF12       │ marchid       │ Architecture ID (read-only)       │
│ 0xF13       │ mimpid        │ Implementation ID (read-only)     │
│ 0xF14       │ mhartid       │ Hardware thread ID (read-only)    │
│ 0x301       │ misa          │ ISA and extensions (read-only)    │
└─────────────┴───────────────┴───────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                     Machine Trap Setup                           │
├─────────────┬───────────────┬───────────────────────────────────┤
│ 0x300       │ mstatus       │ Machine status register           │
│             │               │   [3] MIE: Global interrupt enable│
│             │               │   [7] MPIE: Previous MIE          │
│             │               │   [12:11] MPP: Previous privilege │
├─────────────┼───────────────┼───────────────────────────────────┤
│ 0x304       │ mie           │ Machine interrupt enable          │
│             │               │   [3] software int enable         │
│             │               │   [7] timer int enable            │
│             │               │   [11] external int enable        │
├─────────────┼───────────────┼───────────────────────────────────┤
│ 0x305       │ mtvec         │ Machine trap vector base address  │
│             │               │   [31:2] BASE: Handler address    │
│             │               │   [1:0] MODE: 0=direct, 1=vectored│
└─────────────┴───────────────┴───────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                   Machine Trap Handling                          │
├─────────────┬───────────────┬───────────────────────────────────┤
│ 0x340       │ mscratch      │ Scratch register for handlers     │
├─────────────┼───────────────┼───────────────────────────────────┤
│ 0x341       │ mepc          │ Machine exception program counter │
│             │               │   Saved PC when trap occurs       │
├─────────────┼───────────────┼───────────────────────────────────┤
│ 0x342       │ mcause        │ Machine trap cause                │
│             │               │   [31] Interrupt (1) or Exception│
│             │               │   [30:0] Cause code               │
├─────────────┼───────────────┼───────────────────────────────────┤
│ 0x343       │ mtval         │ Machine trap value                │
│             │               │   Bad address or instruction      │
├─────────────┼───────────────┼───────────────────────────────────┤
│ 0x344       │ mip           │ Machine interrupt pending         │
│             │               │   [3] software int pending        │
│             │               │   [7] timer int pending           │
│             │               │   [11] external int pending       │
└─────────────┴───────────────┴───────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                  Machine Counters/Timers                         │
├─────────────┬───────────────┬───────────────────────────────────┤
│ 0xB00       │ mcycle        │ Cycle counter (lower 32 bits)     │
│ 0xB80       │ mcycleh       │ Cycle counter (upper 32 bits)     │
├─────────────┼───────────────┼───────────────────────────────────┤
│ 0xB02       │ minstret      │ Instructions retired (lower 32)   │
│ 0xB82       │ minstreth     │ Instructions retired (upper 32)   │
└─────────────┴───────────────┴───────────────────────────────────┘
```

---

## Exception and Interrupt Codes

### Exception Codes (mcause[31] = 0)

```
┌──────┬───────────────────────────────┬──────────────────────────┐
│ Code │ Name                          │ Description              │
├──────┼───────────────────────────────┼──────────────────────────┤
│  0   │ Instruction address misaligned│ PC not 4-byte aligned    │
│  1   │ Instruction access fault      │ Fetch from bad address   │
│  2   │ Illegal instruction           │ Unknown/invalid opcode   │
│  3   │ Breakpoint                    │ EBREAK instruction       │
│  4   │ Load address misaligned       │ Misaligned LW/LH/LB      │
│  5   │ Load access fault             │ Load from bad address    │
│  6   │ Store/AMO address misaligned  │ Misaligned SW/SH/SB      │
│  7   │ Store/AMO access fault        │ Store to bad address     │
│  8   │ Environment call from U-mode  │ ECALL in user mode       │
│  9   │ Environment call from S-mode  │ ECALL in supervisor mode │
│ 11   │ Environment call from M-mode  │ ECALL in machine mode    │
│ 12   │ Instruction page fault        │ Virtual memory (not used)│
│ 13   │ Load page fault               │ Virtual memory (not used)│
│ 15   │ Store/AMO page fault          │ Virtual memory (not used)│
└──────┴───────────────────────────────┴──────────────────────────┘
```

### Interrupt Codes (mcause[31] = 1)

```
┌──────┬───────────────────────────────┬──────────────────────────┐
│ Code │ Name                          │ mcause Value             │
├──────┼───────────────────────────────┼──────────────────────────┤
│  3   │ Machine software interrupt    │ 0x80000003               │
│  7   │ Machine timer interrupt       │ 0x80000007               │
│ 11   │ Machine external interrupt    │ 0x8000000B               │
│ 16+  │ Platform-specific interrupts  │ 0x80000010 + N           │
└──────┴───────────────────────────────┴──────────────────────────┘
```

---

## State Transitions

### Normal Execution

```
       RESET
         │
         │ rst_n = 1
         ▼
      ┌──────┐
      │ FETCH├──────────┐
      └───┬──┘          │
          │             │
          │ instr ready │
          ▼             │
      ┌───────┐         │
      │ DECODE│         │
      └───┬───┘         │
          │             │
          │             │
          ▼             │
      ┌────────┐        │
      │ EXECUTE├────────┤
      └───┬────┘        │
          │             │
          │ if mem op   │
          ▼             │
      ┌──────┐          │
      │ MEM  │          │
      └───┬──┘          │
          │             │
          │             │
          ▼             │
      ┌───────┐         │
      │  WB   │         │
      └───┬───┘         │
          │             │
          └─────────────┘
```

### With Trap Handling

```
       RESET
         │
         │ rst_n = 1
         ▼
      ┌──────┐
      │ FETCH├──────────┐
      └───┬──┘          │
          │             │  interrupt_req = 1
          │             │  ┌────────────────┐
          │             │  │                │
          ▼             │  ▼                │
      ┌───────┐      ┌──────┐              │
      │ DECODE│      │ TRAP │              │
      └───┬───┘      └──┬───┘              │
          │             │                   │
          │             │ trap_entry = 1    │
          ▼             │ PC ← trap_vector  │
      ┌────────┐        │                   │
      │ EXECUTE├────────┤                   │
      └───┬────┘        │                   │
          │             │ exception_taken=1 │
          │             │                   │
          │             └───────────────────┘
          ▼
      ┌──────┐
      │ MEM  │
      └───┬──┘
          │
          ▼
      ┌───────┐
      │  WB   │
      └───┬───┘
          │
          └─────────────┘
```

---

## Interrupt Priority Logic

```
┌─────────────────────────────────────────────────────────────┐
│              Interrupt Priority Encoder                      │
│                                                              │
│  Input: mip (pending) & mie (enabled) & mstatus.MIE         │
│                                                              │
│  ┌────────────────────────────────────────────────────┐     │
│  │                                                     │     │
│  │  Priority (Highest to Lowest):                     │     │
│  │                                                     │     │
│  │  1. External Interrupt (bit 11)  ─────┐            │     │
│  │     mcause = 0x8000000B              │            │     │
│  │                                       │            │     │
│  │  2. Software Interrupt (bit 3)   ────┼───┐        │     │
│  │     mcause = 0x80000003              │   │        │     │
│  │                                       │   │        │     │
│  │  3. Timer Interrupt (bit 7)      ────┼───┼───┐    │     │
│  │     mcause = 0x80000007              │   │   │    │     │
│  │                                       │   │   │    │     │
│  │  4. Platform-specific (bits 16-31)   │   │   │    │     │
│  │     mcause = 0x80000000 | bit_number │   │   │    │     │
│  │                                       │   │   │    │     │
│  └───────────────────────────────────────┼───┼───┼────┘     │
│                                          │   │   │          │
│                                          ▼   ▼   ▼          │
│                                       ┌──────────────┐       │
│                                       │   Priority   │       │
│                                       │     MUX      │       │
│                                       └──────┬───────┘       │
│                                              │               │
│                                              │               │
│                                              ▼               │
│                                    interrupt_cause           │
│                                    interrupt_req             │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

---

## Timing Diagrams

### CSR Write (CSRRW)

```
Clock    : __|‾‾|__|‾‾|__|‾‾|__|‾‾|__|‾‾|__|‾‾|__|‾‾|__|‾‾|__

PC       : 0x1000  | 0x1004  | 0x1008  | ...

Instr    : CSRRW x1, mstatus, x2

State    : FETCH   |DECODE   |EXECUTE  |  WB     |FETCH  ...

csr_addr :    X    | 0x300   | 0x300   | 0x300   |   X

csr_op   :    X    | 3'b001  | 3'b001  | 3'b001  |   X

csr_rdata:    X    |   OLD   |   OLD   |   OLD   |   X

csr_wdata:    X    |   NEW   |   NEW   |   NEW   |   X

x1       : OLD_VAL | OLD_VAL | OLD_VAL | OLD_CSR | OLD_CSR

mstatus  : OLD_CSR | OLD_CSR | NEW     | NEW     | NEW
```

### Exception Entry

```
Clock    : __|‾‾|__|‾‾|__|‾‾|__|‾‾|__|‾‾|__|‾‾|__|‾‾|__|‾‾|__

PC       : 0x1000  | 0x1004  | 0x1008  | trap_vec| trap+4

Instr    : ADD     |ILLEGAL  |  ???    | Handler | Handler+

State    : FETCH   |DECODE   |EXECUTE  | TRAP    |FETCH

exception:    0    |    0    |    1    |    0    |   0
taken    :         |         | (detect)|         |

trap_    :    0    |    0    |    1    |    0    |   0
entry    :         |         |         |         |

mepc     :   ???   |   ???   |   ???   | 0x1004  | 0x1004

mcause   :   ???   |   ???   |   ???   |   0x02  | 0x02

mstatus  :         |         |         |         |
  .MIE   :    1    |    1    |    1    |    0    |   0
  .MPIE  :    1    |    1    |    1    |    1    |   1
```

### Interrupt Entry and Return

```
Clock    : __|‾‾|__|‾‾|__|‾‾|__|‾‾|__|‾‾|__|‾‾|__|‾‾|__|‾‾|__|‾‾|__

PC       : 0x2000  | 0x2004  | trap_vec| trap+4  | ...   | 0x2008

Instr    : ADD     | SUB     | Handler | Handler+| MRET  | (resume)

State    : FETCH   |DECODE   | TRAP    |FETCH    | ...   |FETCH

interrupt:    0    |    1    |    0    |    0    |   0   |   0
_req     :         | (timer) |         |         |       |

trap_    :    0    |    1    |    0    |    0    |   0   |   0
entry    :         |         |         |         |       |

trap_    :    0    |    0    |    0    |    0    |   1   |   0
return   :         |         |         |         |(MRET) |

mepc     :   ???   | 0x2004  | 0x2004  | 0x2004  |0x2004 | 0x2004

mcause   :   ???   |0x800007 |0x800007 |0x800007 |0x800007|0x800007

mstatus  :         |         |         |         |       |
  .MIE   :    1    |    0    |    0    |    0    |   1   |   1
  .MPIE  :    0    |    1    |    1    |    1    |   1   |   1
```

---

## Module Interconnections

### CSR Unit Connections

```
┌──────────────────────────────────────────────────────────────┐
│                        CSR Unit                               │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  INPUTS:                                                      │
│    clk, rst_n                    (Clock and reset)           │
│    csr_addr[11:0]               ◄─── Decoder                 │
│    csr_wdata[31:0]              ◄─── Register File (rs1)     │
│    csr_op[2:0]                  ◄─── Decoder                 │
│    trap_entry                   ◄─── State Machine           │
│    trap_return                  ◄─── State Machine (MRET)    │
│    trap_pc[31:0]                ◄─── PC                      │
│    trap_cause[31:0]             ◄─── Exception/Interrupt     │
│    trap_val[31:0]               ◄─── Exception Unit          │
│    interrupts_i[31:0]           ◄─── Interrupt Controller    │
│    instr_retired                ◄─── State Machine           │
│                                                               │
│  OUTPUTS:                                                     │
│    csr_rdata[31:0]              ───► Register File (rd)      │
│    csr_valid                    ───► Decoder                 │
│    trap_vector[31:0]            ───► PC                      │
│    epc_out[31:0]                ───► PC (for MRET)           │
│    interrupt_pending            ───► State Machine           │
│    interrupt_enabled            ───► State Machine           │
│    interrupt_cause[31:0]        ───► State Machine           │
│                                                               │
└───────────────────────────────────────────────────────────────┘
```

### Complete Core with Trap Handling

```
                    ┌───────────────┐
                    │  Peripherals  │
                    └───────┬───────┘
                            │ interrupts
                            │
                    ┌───────▼────────────┐
                    │    Interrupt       │
                    │   Controller       │
                    └───────┬────────────┘
                            │ interrupt_req
                            │ interrupt_cause
                            │
┌───────────────────────────▼─────────────────────────────────┐
│                     RISC-V Core                              │
│                                                              │
│  ┌────────┐   ┌────────┐   ┌──────────┐   ┌─────────┐     │
│  │ Fetch  │──►│ Decode │──►│ Execute  │──►│   WB    │     │
│  └───┬────┘   └────┬───┘   └─────┬────┘   └─────────┘     │
│      │             │              │                         │
│      │             │ is_csr       │ exception_taken         │
│      │             │ csr_addr     │ exception_cause         │
│      │             │ csr_op       │                         │
│      │             │              │                         │
│  ┌───▼─────────────▼──────────────▼─────────────┐           │
│  │                                               │           │
│  │           State Machine / Control            │           │
│  │                                               │           │
│  │  • Check interrupts before fetch             │           │
│  │  • Check exceptions after execute            │           │
│  │  • Handle trap entry                         │           │
│  │  • Handle trap return (MRET)                 │           │
│  │                                               │           │
│  └──────┬────────────────────────┬───────────────┘           │
│         │ trap_entry             │ PC control               │
│         │ trap_return            │                          │
│         │                        │                          │
│  ┌──────▼────────────────────────▼──────────────┐           │
│  │                                               │           │
│  │              CSR Unit                         │           │
│  │                                               │           │
│  │  • mstatus, mie, mip                         │           │
│  │  • mtvec, mepc, mcause, mtval                │           │
│  │  • mcycle, minstret                          │           │
│  │                                               │           │
│  └───────────────────────────────────────────────┘           │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

---

## Summary

### Key Takeaways

1. **CSR Unit** manages system state and trap handling
2. **Exceptions** are synchronous (detected during execution)
3. **Interrupts** are asynchronous (checked before fetch)
4. **Priority** matters: external > software > timer
5. **Trap Entry** saves state and jumps to handler
6. **Trap Return** (MRET) restores state and resumes execution
7. **Integration** requires careful state machine design

### Implementation Order

1. ✅ CSR Unit (registers and operations)
2. ✅ Exception Detection (illegal instruction, misaligned, etc.)
3. ✅ Interrupt Controller (priority encoding)
4. ✅ Trap Entry Logic (save state, jump to handler)
5. ✅ Trap Return Logic (MRET, restore state)
6. ✅ System Instructions (CSRRW/RS/RC, ECALL, EBREAK)
7. ✅ Integration (connect all modules to core)
8. ✅ Testing (unit tests, integration tests, compliance)

### Next Steps

Refer to:
- [CSR_AND_COMPLIANCE_GUIDE.md](CSR_AND_COMPLIANCE_GUIDE.md) for detailed implementation
- [CSR_QUICK_CHECKLIST.md](CSR_QUICK_CHECKLIST.md) for progress tracking

**Good luck with your implementation!** 🚀

---

**Document Version:** 1.0
**Last Updated:** 2025-12-08
**Author:** Custom RISC-V Core Team
